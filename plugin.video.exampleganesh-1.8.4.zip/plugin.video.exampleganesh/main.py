import sys
import os
import json
import re
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon


ADDON_ID = "plugin.video.exampleganesh"
DEFAULT_BASE_URL = "https://www.exampleganesh.com"
DEFAULT_ALLOWED_DOMAIN = "exampleganesh.com"

HANDLE = int(sys.argv[1])
ADDON_URL = sys.argv[0]

# Keep directory pages fast: only this many L1 titles are rendered (and
# therefore only this many L4 pages are queried for artwork) at a time.
ITEMS_PER_PAGE = 15
REQUEST_TIMEOUT = 15
CACHE_TTL = 900
ART_CACHE_TTL = 86400
MAX_RECENT_SEARCHES = 8
DEFAULT_POSTER_VIEW_ID = 50

CONFIG_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/%s/config.json" % ADDON_ID
)
CACHE_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/%s/cache.json" % ADDON_ID
)


def clean_title(text):
    return " ".join(text.split()).strip() if text else ""


def make_url(params):
    return ADDON_URL + "?" + urllib.parse.urlencode(params)


def save_config(config):
    try:
        folder = os.path.dirname(CONFIG_PATH)
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        f = xbmcvfs.File(CONFIG_PATH, "w")
        f.write(json.dumps(config))
        f.close()
        return True
    except Exception as e:
        xbmc.log("ExampleGanesh config save error: " + str(e), xbmc.LOGERROR)
        return False


def load_config():
    default_config = {
        "base_url": DEFAULT_BASE_URL,
        "allowed_domain": DEFAULT_ALLOWED_DOMAIN,
    }
    try:
        folder = os.path.dirname(CONFIG_PATH)
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        if not xbmcvfs.exists(CONFIG_PATH):
            save_config(default_config)
            return default_config
        f = xbmcvfs.File(CONFIG_PATH)
        data = f.read()
        f.close()
        if not data:
            return default_config
        config = json.loads(data)
        if not config.get("base_url"):
            config["base_url"] = DEFAULT_BASE_URL
        if not config.get("allowed_domain"):
            config["allowed_domain"] = DEFAULT_ALLOWED_DOMAIN
        return config
    except Exception as e:
        xbmc.log("ExampleGanesh config load error: " + str(e), xbmc.LOGERROR)
        return default_config


def get_base_url():
    return load_config().get("base_url", DEFAULT_BASE_URL)


def get_allowed_domain():
    config = load_config()
    domain = config.get("allowed_domain", "").strip().lower()
    if domain:
        return domain
    return urllib.parse.urlparse(config.get("base_url", DEFAULT_BASE_URL)).netloc.lower().replace("www.", "")


_HTML_CACHE = {}

def _load_cache_store():
    try:
        if not xbmcvfs.exists(CACHE_PATH):
            return {"html": {}, "art": {}, "recent_searches": []}
        f = xbmcvfs.File(CACHE_PATH)
        data = f.read()
        f.close()
        store = json.loads(data) if data else {}
        store.setdefault("html", {})
        store.setdefault("art", {})
        store.setdefault("recent_searches", [])
        return store
    except Exception as e:
        xbmc.log("ExampleGanesh cache load error: %s" % str(e), xbmc.LOGWARNING)
        return {"html": {}, "art": {}, "recent_searches": []}

def _save_cache_store(store):
    try:
        folder = os.path.dirname(CACHE_PATH)
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        f = xbmcvfs.File(CACHE_PATH, "w")
        f.write(json.dumps(store))
        f.close()
    except Exception as e:
        xbmc.log("ExampleGanesh cache save error: %s" % str(e), xbmc.LOGWARNING)

def get_html(url, force_refresh=False):
    now = time.time()
    cached = _HTML_CACHE.get(url)
    if not force_refresh and cached and now - cached.get("time", 0) < CACHE_TTL:
        return cached["html"], cached["final_url"]

    store = _load_cache_store()
    disk = store["html"].get(url)
    if not force_refresh and disk and now - disk.get("time", 0) < CACHE_TTL:
        result = (disk.get("html", ""), disk.get("final_url", url))
        _HTML_CACHE[url] = {"time": disk.get("time", now), "html": result[0], "final_url": result[1]}
        return result

    headers = {"User-Agent": "Mozilla/5.0 Kodi Addon"}
    response = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
    response.raise_for_status()
    result = (response.text, response.url)
    _HTML_CACHE[url] = {"time": now, "html": result[0], "final_url": result[1]}
    store["html"][url] = {"time": now, "html": result[0], "final_url": result[1]}
    # Keep the persistent cache bounded.
    if len(store["html"]) > 80:
        oldest = sorted(store["html"].items(), key=lambda kv: kv[1].get("time", 0))[:20]
        for key, _ in oldest:
            store["html"].pop(key, None)
    _save_cache_store(store)
    return result


def is_allowed_url(url):
    if url.startswith("magnet:"):
        return True
    domain = urllib.parse.urlparse(url).netloc.lower()
    if not domain:
        return True
    return get_allowed_domain() in domain


def set_art(li, art):
    if art:
        li.setArt({"thumb": art, "icon": art, "fanart": art})


def add_folder(title, action, url="", section_index=None, item_index=None, art="", label2=""):
    li = xbmcgui.ListItem(label=title, label2=label2)
    set_art(li, art)
    li.setProperty("IsPlayable", "false")
    li.setInfo("video", {"title": title})
    params = {"action": action}
    if url:
        params["url"] = url
    if section_index is not None:
        params["section_index"] = str(section_index)
    if item_index is not None:
        params["item_index"] = str(item_index)
    xbmcplugin.addDirectoryItem(HANDLE, make_url(params), li, isFolder=True)


def add_page_link(title, url, art=""):
    li = xbmcgui.ListItem(label=title)
    set_art(li, art)
    li.setInfo("video", {"title": title})
    xbmcplugin.addDirectoryItem(HANDLE, make_url({"action": "open", "url": url}), li, isFolder=True)


def add_magnet(title, magnet, art=""):
    li = xbmcgui.ListItem(label=title)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": title})
    set_art(li, art)
    elementum_url = "plugin://plugin.video.elementum/play?uri=" + urllib.parse.quote(magnet, safe="")
    xbmcplugin.addDirectoryItem(HANDLE, elementum_url, li, isFolder=False)


_IMAGE_CACHE = {}


def get_image_from_link(url):
    """Fetch the deeper page and extract poster artwork, with persistent caching."""
    if not url:
        return ""

    now = time.time()
    cached = _IMAGE_CACHE.get(url)
    if cached and now - cached.get("time", 0) < ART_CACHE_TTL:
        return cached.get("art", "")

    store = _load_cache_store()
    disk = store["art"].get(url)
    if disk and now - disk.get("time", 0) < ART_CACHE_TTL:
        art = disk.get("art", "")
        _IMAGE_CACHE[url] = {"time": disk.get("time", now), "art": art}
        return art

    try:
        html, final_url = get_html(url)
        soup = BeautifulSoup(html, "html.parser")
        art = get_page_image(soup, final_url)
    except Exception as e:
        xbmc.log("ExampleGanesh image fetch error for %s: %s" % (url, str(e)), xbmc.LOGWARNING)
        art = ""

    _IMAGE_CACHE[url] = {"time": now, "art": art}
    store["art"][url] = {"time": now, "art": art}
    if len(store["art"]) > 300:
        oldest = sorted(store["art"].items(), key=lambda kv: kv[1].get("time", 0))[:75]
        for key, _ in oldest:
            store["art"].pop(key, None)
    _save_cache_store(store)
    return art


def get_page_image(soup, final_url):
    """Use first meaningful poster image from forum post content as thumb/icon/fanart."""
    content = soup.select_one(".cPost_contentWrap [data-role='commentContent']")
    search_area = content if content else soup
    for img in search_area.select("img"):
        src = img.get("src") or img.get("data-src") or img.get("data-original")
        if not src:
            continue
        src_lower = src.lower()
        alt_lower = (img.get("alt") or "").lower()
        if (
            src_lower.endswith(".gif")
            or "border" in src_lower
            or "client-icon" in src_lower
            or "telegram" in src_lower
            or "logo" in src_lower
            or "border" in alt_lower
            or "client-icon" in alt_lower
        ):
            continue
        return urllib.parse.urljoin(final_url, src)

    for selector, attr in [
        ("meta[property='og:image']", "content"),
        ("meta[name='twitter:image']", "content"),
        ("article img", "src"),
        ("img", "src"),
    ]:
        tag = soup.select_one(selector)
        if tag and tag.get(attr):
            return urllib.parse.urljoin(final_url, tag.get(attr))
    return ""


def link_label(a):
    text = clean_title(a.get_text(" ", strip=True))
    lower = text.lower()
    if "doc" in lower or "documentation" in lower:
        return "Documentation"
    if "spec" in lower:
        return "Specs"
    if any(x in lower for x in ["source", "binary", "package", "download"]):
        return "Package"
    return text or "Open Link"


def title_from_anchor(a):
    text = clean_title(a.get_text(" ", strip=True))
    if not text:
        text = clean_title(a.get("title", "")) or clean_title(a.get("aria-label", ""))
    return text or "Open Link"


def previous_inline_text_before_anchor(a):
    parts = []
    for sibling in a.previous_siblings:
        if getattr(sibling, "name", None) == "br":
            break
        txt = sibling.get_text(" ", strip=True) if hasattr(sibling, "get_text") else str(sibling)
        txt = clean_title(txt)
        if txt:
            parts.insert(0, txt)
    return clean_title(" ".join(parts))


def extract_anchor_item_title(a):
    """Change 1: every visible anchor is an independent item, even inside same strong."""
    anchor_text = title_from_anchor(a)
    prefix = previous_inline_text_before_anchor(a)

    if prefix and anchor_text:
        # Example: Anaganaga - [4K, 1080p] => include prefix + anchor text.
        combined = clean_title(prefix + " " + anchor_text)
        return combined.strip(" -")

    return anchor_text.strip(" -")


def extract_sections(soup):
    sections = []
    widgets = soup.select("li.ipsWidget")

    for widget in widgets:
        header = widget.select_one(".banger-header")
        if not header:
            continue
        section_title = clean_title(header.get_text(" ", strip=True))
        if not section_title:
            continue

        items = []
        seen = set()

        # Each anchor becomes its own item. This fixes multiple links inside one <strong>.
        for a in widget.select("strong a[href]"):
            href = a.get("href", "").strip()
            if not href or href.startswith("mailto:") or href.startswith("#"):
                continue

            title = extract_anchor_item_title(a)
            if not title:
                continue

            key = (title.lower(), href)
            if key in seen:
                continue
            seen.add(key)

            items.append({
                "title": title,
                "links": [{"label": "Open", "url": href}],
            })

        if items:
            sections.append({"title": section_title, "items": items})

    return sections


def title_from_dn(magnet):
    parsed = urllib.parse.urlparse(magnet)
    query = urllib.parse.parse_qs(parsed.query)
    dn = query.get("dn", [""])[0]
    if dn:
        return clean_title(urllib.parse.unquote_plus(dn).replace(".", " ").replace("_", " "))
    return ""


def simplify_quality_title(full_title, magnet=""):
    text = clean_title(full_title).replace(".torrent", "")
    # Normalize spaces and separators.
    text = re.sub(r"\s+", " ", text).strip(" :-")

    # Prefer explicit quality + size from full title.
    quality_match = re.search(r"(?i)(2160p|4k|1080p|720p|480p|360p)", text)
    size_match = re.search(r"(?i)(\d+(?:\.\d+)?\s*(?:GB|MB))", text)
    if quality_match and size_match:
        return clean_title(quality_match.group(1) + " - " + size_match.group(1))
    if quality_match:
        return clean_title(quality_match.group(1))
    if size_match:
        return clean_title(size_match.group(1))

    # Fallback to dn= when title text is not useful.
    dn = title_from_dn(magnet)
    if dn:
        quality_match = re.search(r"(?i)(2160p|4k|1080p|720p|480p|360p)", dn)
        size_match = re.search(r"(?i)(\d+(?:\.\d+)?\s*(?:GB|MB))", dn)
        if quality_match and size_match:
            return clean_title(quality_match.group(1) + " - " + size_match.group(1))
        if quality_match:
            return clean_title(quality_match.group(1))
        if size_match:
            return clean_title(size_match.group(1))

    return dn or "Magnet Link"


def get_magnet_full_title_from_previous_nodes(magnet_tag):
    current = magnet_tag.previous_element
    while current:
        if getattr(current, "name", None) == "strong":
            text = clean_title(current.get_text(" ", strip=True))
            lower = text.lower()
            if (
                text
                and "telegram" not in lower
                and "official" not in lower
                and "click here" not in lower
                and "torrent" not in lower
                and "direct link" not in lower
                and len(text) > 5
            ):
                return text
        current = current.previous_element
    return ""


def extract_magnets_from_page(soup, final_url):
    page_art = get_page_image(soup, final_url)
    magnets = []
    seen = set()

    content = soup.select_one(".cPost_contentWrap [data-role='commentContent']")
    search_area = content if content else soup

    for a in search_area.select('a[href^="magnet:"]'):
        magnet = a.get("href", "").strip()
        if not magnet or magnet in seen:
            continue
        seen.add(magnet)

        full_title = get_magnet_full_title_from_previous_nodes(a)
        if not full_title:
            full_title = title_from_dn(magnet)
        title = simplify_quality_title(full_title, magnet)

        magnets.append({"title": title, "magnet": magnet, "art": page_art})

    return magnets


def list_home():
    configure_browse_ui("Home")
    add_folder("Open Website", "open", get_base_url())
    add_search_entry()
    add_folder("Website Setup", "setup")
    add_folder("Clear Cache", "clear_cache")
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def website_setup():
    config = load_config()
    current_url = config.get("base_url", DEFAULT_BASE_URL)
    current_domain = config.get("allowed_domain", DEFAULT_ALLOWED_DOMAIN)

    new_url = xbmcgui.Dialog().input("Website URL", defaultt=current_url, type=xbmcgui.INPUT_ALPHANUM)
    if not new_url:
        xbmc.executebuiltin("Container.Refresh")
        return
    new_url = new_url.strip()
    parsed_domain = urllib.parse.urlparse(new_url).netloc.lower().replace("www.", "")

    new_domain = xbmcgui.Dialog().input(
        "Allowed Domain",
        defaultt=parsed_domain or current_domain,
        type=xbmcgui.INPUT_ALPHANUM,
    )
    if not new_domain:
        new_domain = parsed_domain or current_domain

    if save_config({"base_url": new_url, "allowed_domain": new_domain.strip().lower()}):
        xbmcgui.Dialog().ok("Saved", "Website updated successfully:\n\n" + new_url)
    else:
        xbmcgui.Dialog().ok("Error", "Failed to save website setup")
    xbmc.executebuiltin("Container.Refresh")


def get_poster_view_id():
    try:
        value = xbmcaddon.Addon(ADDON_ID).getSetting("poster_view_id")
        return int(value) if value.strip() else DEFAULT_POSTER_VIEW_ID
    except Exception:
        return DEFAULT_POSTER_VIEW_ID


def apply_poster_view():
    """Request the configured poster view for the current Kodi container."""
    try:
        xbmc.executebuiltin("Container.SetViewMode(%d)" % get_poster_view_id())
    except Exception as e:
        xbmc.log("ExampleGanesh poster view warning: %s" % str(e), xbmc.LOGWARNING)


def configure_browse_ui(category="Browse"):
    """Ask Kodi skins for poster/movie-style presentation where supported."""
    try:
        xbmcplugin.setPluginCategory(HANDLE, category)
        xbmcplugin.setContent(HANDLE, "movies")
    except Exception as e:
        xbmc.log("ExampleGanesh UI setup warning: %s" % str(e), xbmc.LOGWARNING)


def clear_cache():
    global _HTML_CACHE, _IMAGE_CACHE
    _HTML_CACHE = {}
    _IMAGE_CACHE = {}
    try:
        if xbmcvfs.exists(CACHE_PATH):
            xbmcvfs.delete(CACHE_PATH)
        xbmcgui.Dialog().notification("Cache", "Cache cleared", xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as e:
        xbmc.log("ExampleGanesh cache clear error: %s" % str(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Cache", "Failed to clear cache", xbmcgui.NOTIFICATION_ERROR, 2500)
    xbmc.executebuiltin("Container.Refresh")


def add_search_entry(section_index=None):
    params = {"action": "search"}
    if section_index is not None:
        params["section_index"] = str(section_index)
    li = xbmcgui.ListItem(label="Search Titles")
    li.setArt({"icon": "DefaultAddSource.png", "thumb": "DefaultAddSource.png"})
    li.setInfo("video", {"title": "Search Titles"})
    xbmcplugin.addDirectoryItem(HANDLE, make_url(params), li, isFolder=True)


def add_pagination(title, action, url, section_index, page, art=""):
    li = xbmcgui.ListItem(label=title)
    set_art(li, art)
    params = {
        "action": action,
        "url": url,
        "section_index": str(section_index),
        "page": str(page),
    }
    xbmcplugin.addDirectoryItem(HANDLE, make_url(params), li, isFolder=True)


def get_recent_searches():
    return _load_cache_store().get("recent_searches", [])[:MAX_RECENT_SEARCHES]

def remember_search(term):
    term = clean_title(term)
    if not term:
        return
    store = _load_cache_store()
    searches = [x for x in store.get("recent_searches", []) if x.casefold() != term.casefold()]
    searches.insert(0, term)
    store["recent_searches"] = searches[:MAX_RECENT_SEARCHES]
    _save_cache_store(store)

def prompt_search():
    try:
        recent = get_recent_searches()
        if recent:
            options = ["New Search"] + recent
            choice = xbmcgui.Dialog().select("Search Titles", options)
            if choice < 0:
                return ""
            if choice > 0:
                return recent[choice - 1]
        return xbmcgui.Dialog().input("Search Titles", type=xbmcgui.INPUT_ALPHANUM).strip()
    except Exception:
        return ""


def list_sections(url):
    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Addon Error", "Failed to open website", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh website open error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    page_art = get_page_image(soup, final_url)

    magnets = extract_magnets_from_page(soup, final_url)
    if magnets:
        configure_browse_ui("Latest")
        for m in magnets:
            add_magnet(m["title"], m["magnet"], m["art"])
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    sections = extract_sections(soup)
    configure_browse_ui("Browse")
    if not sections:
        xbmcgui.Dialog().notification("No Content", "No sections or magnets found", xbmcgui.NOTIFICATION_WARNING, 4000)

    for index, section in enumerate(sections):
        add_folder(section["title"], "section", final_url, section_index=index, art=page_art)
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def fetch_visible_artwork(items, final_url, fallback_art=""):
    """Fetch visible L4 artwork concurrently without changing item order."""
    results = [fallback_art] * len(items)

    def fetch_one(index, item):
        for link in item.get("links", []):
            href = link.get("url", "")
            full_url = urllib.parse.urljoin(final_url, href)
            if full_url.startswith("http") and is_allowed_url(full_url):
                art = get_image_from_link(full_url)
                if art:
                    return index, art
        return index, fallback_art

    # A small pool keeps Kodi responsive while avoiding a large request burst.
    with ThreadPoolExecutor(max_workers=min(5, max(1, len(items)))) as executor:
        futures = [executor.submit(fetch_one, i, item) for i, item in enumerate(items)]
        for future in as_completed(futures):
            try:
                index, art = future.result()
                results[index] = art
            except Exception as e:
                xbmc.log("ExampleGanesh artwork worker error: %s" % str(e), xbmc.LOGWARNING)

    return results


def render_section_items(url, final_url, section, section_index, page=0, search_term="", fallback_art=""):
    """Render only one L1 page, so L4 artwork is fetched only for visible titles."""
    items = section["items"]
    if search_term:
        needle = search_term.casefold()
        items = [item for item in items if needle in item["title"].casefold()]

    total = len(items)
    start = max(0, int(page) * ITEMS_PER_PAGE)
    visible = items[start:start + ITEMS_PER_PAGE]

    artwork = fetch_visible_artwork(visible, final_url, fallback_art)

    for relative_index, item in enumerate(visible):
        original_index = next(
            (i for i, candidate in enumerate(section["items"]) if candidate is item),
            start + relative_index,
        )
        item_art = artwork[relative_index]

        add_folder(
            item["title"],
            "item",
            final_url,
            section_index=section_index,
            item_index=original_index,
            art=item_art,
        )

    if not search_term and start > 0:
        add_pagination("Previous", "section", final_url, section_index, page - 1)
    if not search_term and start + ITEMS_PER_PAGE < total:
        add_pagination("Next", "section", final_url, section_index, page + 1)


def list_section_items(url, section_index, page=0):
    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Addon Error", "Failed to open section", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh section open error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    sections = extract_sections(soup)

    try:
        section = sections[int(section_index)]
    except Exception:
        xbmcgui.Dialog().notification("Addon Error", "Section not found", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    configure_browse_ui(section["title"])
    add_search_entry(section_index)
    render_section_items(url, final_url, section, int(section_index), int(page), fallback_art=get_page_image(soup, final_url))
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def search_titles(url, section_index=None):
    term = prompt_search()
    if not term:
        xbmc.executebuiltin("Container.Refresh")
        return
    remember_search(term)

    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Search Error", "Failed to search website", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh search error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    sections = extract_sections(soup)
    needle = term.casefold()

    # With a section index, search every title in that section, not just the
    # currently visible 15. Without it, search all L1 sections on the page.
    if section_index is not None:
        selected = [(int(section_index), sections[int(section_index)])] if 0 <= int(section_index) < len(sections) else []
    else:
        selected = list(enumerate(sections))

    configure_browse_ui("Search: " + term)
    matches = []
    for sec_index, section in selected:
        for item_index, item in enumerate(section["items"]):
            if needle in item["title"].casefold():
                matches.append((sec_index, section["title"], item_index, item))

    artwork = fetch_visible_artwork([m[3] for m in matches], final_url)
    found = len(matches)
    for match_index, (sec_index, section_title, item_index, item) in enumerate(matches):
        add_folder(
            item["title"],
            "item",
            final_url,
            section_index=sec_index,
            item_index=item_index,
            art=artwork[match_index],
            label2=section_title,
        )

    if not found:
        xbmcgui.Dialog().notification("Search", "No matching titles found", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def list_item_links(url, section_index, item_index):
    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Addon Error", "Failed to open item", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh item open error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    page_art = get_page_image(soup, final_url)

    magnets = extract_magnets_from_page(soup, final_url)
    if magnets:
        for m in magnets:
            add_magnet(m["title"], m["magnet"], m["art"])
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    sections = extract_sections(soup)
    try:
        item = sections[int(section_index)]["items"][int(item_index)]
    except Exception:
        xbmcgui.Dialog().notification("Addon Error", "Item not found", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    seen = set()
    for link in item["links"]:
        label = link["label"]
        href = link["url"]
        full_url = urllib.parse.urljoin(final_url, href)
        if full_url in seen:
            continue
        seen.add(full_url)
        if full_url.startswith("magnet:"):
            add_magnet(label, full_url, page_art)
        elif full_url.startswith("http") and is_allowed_url(full_url):
            # Skip the extra intermediate directory item when the linked page
            # contains result entries that the addon already knows how to show.
            try:
                result_html, result_final_url = get_html(full_url)
                result_soup = BeautifulSoup(result_html, "html.parser")
                result_magnets = extract_magnets_from_page(result_soup, result_final_url)
            except Exception as e:
                xbmc.log("ExampleGanesh direct result fetch error: %s" % str(e), xbmc.LOGWARNING)
                result_magnets = []
            if result_magnets:
                configure_browse_ui("Results")
                for m in result_magnets:
                    add_magnet(m["title"], m["magnet"], m["art"])
                xbmcplugin.endOfDirectory(HANDLE)
                apply_poster_view()
                return
            add_page_link(label, full_url, page_art)
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action")
    url = params.get("url", get_base_url())

    if action == "setup":
        website_setup()
    elif action == "clear_cache":
        clear_cache()
    elif action == "open":
        list_sections(url)
    elif action == "section":
        list_section_items(url, params.get("section_index", "0"), params.get("page", "0"))
    elif action == "search":
        list_sections_url = url
        list_section_index = params.get("section_index")
        search_titles(list_sections_url, list_section_index)
    elif action == "item":
        list_item_links(url, params.get("section_index", "0"), params.get("item_index", "0"))
    else:
        list_home()


router()
