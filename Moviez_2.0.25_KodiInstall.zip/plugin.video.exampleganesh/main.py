import sys
import os
import json
import re
import time
import math
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon


ADDON_ID = "plugin.video.exampleganesh"
DEFAULT_BASE_URL = "https://www.exampleganesh.com"
DEFAULT_ALLOWED_DOMAIN = "exampleganesh.com"

HANDLE = int(sys.argv[1])
ADDON_URL = sys.argv[0]

# Keep directory pages fast: only this many L1 titles are rendered (and
# therefore only this many L4 pages are queried for artwork) at a time.
ITEMS_PER_PAGE = 15
REQUEST_TIMEOUT = 15
CACHE_TTL = 900
ART_CACHE_TTL = 86400
MAX_RECENT_SEARCHES = 8
MAX_RECENTLY_PLAYED = 20
HOME_AUTO_SCROLL_IDLE_SECONDS = 30.0
HERO_PAN_LEG_SECONDS = 12.0
DEFAULT_POSTER_VIEW_ID = 50

# The featured poster is rendered at full banner width and moved through the
# banner window. Cache its source dimensions so selection changes stay quick.
_POSTER_DIMENSIONS_CACHE = {}

CONFIG_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/%s/config.json" % ADDON_ID
)
CACHE_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/%s/cache.json" % ADDON_ID
)


def clean_title(text):
    """Normalize visible text from HTML fragments without exposing markup."""
    if not text:
        return ""
    try:
        # Website posts occasionally include literal HTML fragments as text.
        if "<" in text and ">" in text:
            text = BeautifulSoup(text, "html.parser").get_text(" ", strip=True)
        text = urllib.parse.unquote(text)
    except Exception:
        pass
    text = text.replace("\xa0", " ")
    return " ".join(str(text).split()).strip()


def _read_image_dimensions(data):
    """Read common raster image dimensions from a small header prefix."""
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
        return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
    if data[:3] == b"GIF" and len(data) >= 10:
        return int.from_bytes(data[6:8], "little"), int.from_bytes(data[8:10], "little")
    if data[:2] == b"BM" and len(data) >= 26:
        return abs(int.from_bytes(data[18:22], "little", signed=True)), abs(int.from_bytes(data[22:26], "little", signed=True))
    if data[:4] == b"RIFF" and len(data) >= 30 and data[8:12] == b"WEBP":
        chunk = data[12:16]
        if chunk == b"VP8X":
            return 1 + int.from_bytes(data[24:27], "little"), 1 + int.from_bytes(data[27:30], "little")
        if chunk == b"VP8L" and len(data) >= 25 and data[20] == 0x2F:
            b1, b2, b3, b4 = data[21:25]
            width = 1 + (((b2 & 0x3F) << 8) | b1)
            height = 1 + (((b4 & 0x0F) << 10) | (b3 << 2) | ((b2 & 0xC0) >> 6))
            return width, height
        if chunk == b"VP8 " and len(data) >= 30 and data[23:26] == b"\x9d\x01\x2a":
            return int.from_bytes(data[26:28], "little") & 0x3FFF, int.from_bytes(data[28:30], "little") & 0x3FFF
    if data[:2] == b"\xff\xd8":
        sof_markers = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
        offset = 2
        while offset + 4 <= len(data):
            if data[offset] != 0xFF:
                offset += 1
                continue
            while offset < len(data) and data[offset] == 0xFF:
                offset += 1
            if offset >= len(data):
                break
            marker = data[offset]
            offset += 1
            if marker in (0xD8, 0xD9, 0x01) or 0xD0 <= marker <= 0xD7:
                continue
            if offset + 2 > len(data):
                break
            segment_length = int.from_bytes(data[offset:offset + 2], "big")
            if segment_length < 2:
                break
            if marker in sof_markers and offset + 7 <= len(data):
                height = int.from_bytes(data[offset + 3:offset + 5], "big")
                width = int.from_bytes(data[offset + 5:offset + 7], "big")
                return width, height
            offset += segment_length
    return None


def _poster_dimensions(url):
    """Fetch only enough of a poster to identify its aspect ratio."""
    if not url:
        return None
    cached = _POSTER_DIMENSIONS_CACHE.get(url)
    if cached is not None:
        return cached
    dimensions = None
    if str(url).startswith(("http://", "https://")):
        try:
            with requests.get(url, headers={"User-Agent": "Mozilla/5.0 Kodi Addon"},
                              stream=True, timeout=(0.7, 1.0), allow_redirects=True) as response:
                response.raise_for_status()
                prefix = bytearray()
                for chunk in response.iter_content(chunk_size=2048):
                    if not chunk:
                        continue
                    prefix.extend(chunk)
                    dimensions = _read_image_dimensions(prefix)
                    if dimensions or len(prefix) >= 65536:
                        break
        except Exception:
            dimensions = None
    if dimensions and dimensions[0] > 0 and dimensions[1] > 0:
        _POSTER_DIMENSIONS_CACHE[url] = dimensions
    else:
        # Most source artwork is portrait poster art. This keeps a useful
        # pan if the host blocks dimension probing or the URL is Kodi-local.
        dimensions = (2, 3)
        _POSTER_DIMENSIONS_CACHE[url] = dimensions
    if len(_POSTER_DIMENSIONS_CACHE) > 120:
        _POSTER_DIMENSIONS_CACHE.pop(next(iter(_POSTER_DIMENSIONS_CACHE)))
    return dimensions


def make_url(params):
    return ADDON_URL + "?" + urllib.parse.urlencode(params)


def save_config(config):
    try:
        folder = os.path.dirname(CONFIG_PATH)
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        f = xbmcvfs.File(CONFIG_PATH, "w")
        f.write(json.dumps(config))
        f.close()
        return True
    except Exception as e:
        xbmc.log("ExampleGanesh config save error: " + str(e), xbmc.LOGERROR)
        return False


def load_config():
    default_config = {
        "base_url": DEFAULT_BASE_URL,
        "allowed_domain": DEFAULT_ALLOWED_DOMAIN,
    }
    try:
        folder = os.path.dirname(CONFIG_PATH)
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        if not xbmcvfs.exists(CONFIG_PATH):
            save_config(default_config)
            return default_config
        f = xbmcvfs.File(CONFIG_PATH)
        data = f.read()
        f.close()
        if not data:
            return default_config
        config = json.loads(data)
        if not config.get("base_url"):
            config["base_url"] = DEFAULT_BASE_URL
        if not config.get("allowed_domain"):
            config["allowed_domain"] = DEFAULT_ALLOWED_DOMAIN
        return config
    except Exception as e:
        xbmc.log("ExampleGanesh config load error: " + str(e), xbmc.LOGERROR)
        return default_config


def get_base_url():
    return load_config().get("base_url", DEFAULT_BASE_URL)


def get_allowed_domain():
    config = load_config()
    domain = config.get("allowed_domain", "").strip().lower()
    if domain:
        return domain
    return urllib.parse.urlparse(config.get("base_url", DEFAULT_BASE_URL)).netloc.lower().replace("www.", "")


_HTML_CACHE = {}

def _load_cache_store():
    try:
        if not xbmcvfs.exists(CACHE_PATH):
            return {"html": {}, "art": {}, "recent_searches": [], "recently_played": []}
        f = xbmcvfs.File(CACHE_PATH)
        data = f.read()
        f.close()
        store = json.loads(data) if data else {}
        store.setdefault("html", {})
        store.setdefault("art", {})
        store.setdefault("recent_searches", [])
        store.setdefault("recently_played", [])
        return store
    except Exception as e:
        xbmc.log("ExampleGanesh cache load error: %s" % str(e), xbmc.LOGWARNING)
        return {"html": {}, "art": {}, "recent_searches": [], "recently_played": []}

def _save_cache_store(store):
    try:
        folder = os.path.dirname(CACHE_PATH)
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        f = xbmcvfs.File(CACHE_PATH, "w")
        f.write(json.dumps(store))
        f.close()
    except Exception as e:
        xbmc.log("ExampleGanesh cache save error: %s" % str(e), xbmc.LOGWARNING)

def get_html(url, force_refresh=False):
    now = time.time()
    cached = _HTML_CACHE.get(url)
    if not force_refresh and cached and now - cached.get("time", 0) < CACHE_TTL:
        return cached["html"], cached["final_url"]

    store = _load_cache_store()
    disk = store["html"].get(url)
    if not force_refresh and disk and now - disk.get("time", 0) < CACHE_TTL:
        result = (disk.get("html", ""), disk.get("final_url", url))
        _HTML_CACHE[url] = {"time": disk.get("time", now), "html": result[0], "final_url": result[1]}
        return result

    headers = {"User-Agent": "Mozilla/5.0 Kodi Addon"}
    response = requests.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
    response.raise_for_status()
    result = (response.text, response.url)
    _HTML_CACHE[url] = {"time": now, "html": result[0], "final_url": result[1]}
    store["html"][url] = {"time": now, "html": result[0], "final_url": result[1]}
    # Keep the persistent cache bounded.
    if len(store["html"]) > 80:
        oldest = sorted(store["html"].items(), key=lambda kv: kv[1].get("time", 0))[:20]
        for key, _ in oldest:
            store["html"].pop(key, None)
    _save_cache_store(store)
    return result


def is_allowed_url(url):
    if url.startswith("magnet:"):
        return True
    domain = urllib.parse.urlparse(url).netloc.lower()
    if not domain:
        return True
    allowed = get_allowed_domain().strip().lower().lstrip(".")
    host = domain.split(":", 1)[0].rstrip(".")
    return bool(allowed) and (host == allowed or host.endswith("." + allowed))


def set_art(li, art):
    if art:
        li.setArt({"thumb": art, "icon": art, "fanart": art})


def add_folder(title, action, url="", section_index=None, item_index=None, art="", label2=""):
    li = xbmcgui.ListItem(label=title, label2=label2)
    set_art(li, art)
    li.setProperty("IsPlayable", "false")
    li.setInfo("video", {"title": title})
    params = {"action": action}
    if url:
        params["url"] = url
    if section_index is not None:
        params["section_index"] = str(section_index)
    if item_index is not None:
        params["item_index"] = str(item_index)
    xbmcplugin.addDirectoryItem(HANDLE, make_url(params), li, isFolder=True)


def add_page_link(title, url, art=""):
    li = xbmcgui.ListItem(label=title)
    set_art(li, art)
    li.setInfo("video", {"title": title})
    xbmcplugin.addDirectoryItem(HANDLE, make_url({"action": "open", "url": url}), li, isFolder=True)


def add_magnet(title, magnet, art=""):
    li = xbmcgui.ListItem(label=title)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": title})
    set_art(li, art)
    play_url = make_url({"action": "play_magnet", "magnet": magnet, "title": title, "art": art})
    xbmcplugin.addDirectoryItem(HANDLE, play_url, li, isFolder=False)


_IMAGE_CACHE = {}


def get_image_from_link(url):
    """Fetch the deeper page and extract poster artwork, with persistent caching."""
    if not url:
        return ""

    now = time.time()
    cached = _IMAGE_CACHE.get(url)
    if cached and now - cached.get("time", 0) < ART_CACHE_TTL:
        return cached.get("art", "")

    store = _load_cache_store()
    disk = store["art"].get(url)
    if disk and now - disk.get("time", 0) < ART_CACHE_TTL:
        art = disk.get("art", "")
        _IMAGE_CACHE[url] = {"time": disk.get("time", now), "art": art}
        return art

    try:
        html, final_url = get_html(url)
        soup = BeautifulSoup(html, "html.parser")
        art = get_page_image(soup, final_url)
    except Exception as e:
        xbmc.log("ExampleGanesh image fetch error for %s: %s" % (url, str(e)), xbmc.LOGWARNING)
        art = ""

    _IMAGE_CACHE[url] = {"time": now, "art": art}
    store["art"][url] = {"time": now, "art": art}
    if len(store["art"]) > 300:
        oldest = sorted(store["art"].items(), key=lambda kv: kv[1].get("time", 0))[:75]
        for key, _ in oldest:
            store["art"].pop(key, None)
    _save_cache_store(store)
    return art


def get_page_image(soup, final_url):
    """Use first meaningful poster image from forum post content as thumb/icon/fanart."""
    content = soup.select_one(".cPost_contentWrap [data-role='commentContent']")
    search_area = content if content else soup
    for img in search_area.select("img"):
        src = img.get("src") or img.get("data-src") or img.get("data-original")
        if not src:
            continue
        src_lower = src.lower()
        alt_lower = (img.get("alt") or "").lower()
        if (
            src_lower.endswith(".gif")
            or "border" in src_lower
            or "client-icon" in src_lower
            or "telegram" in src_lower
            or "logo" in src_lower
            or "border" in alt_lower
            or "client-icon" in alt_lower
        ):
            continue
        return urllib.parse.urljoin(final_url, src)

    for selector, attr in [
        ("meta[property='og:image']", "content"),
        ("meta[name='twitter:image']", "content"),
        ("article img", "src"),
        ("img", "src"),
    ]:
        tag = soup.select_one(selector)
        if tag and tag.get(attr):
            return urllib.parse.urljoin(final_url, tag.get(attr))
    return ""


def link_label(a):
    text = clean_title(a.get_text(" ", strip=True))
    lower = text.lower()
    if "doc" in lower or "documentation" in lower:
        return "Documentation"
    if "spec" in lower:
        return "Specs"
    if any(x in lower for x in ["source", "binary", "package", "download"]):
        return "Package"
    return text or "Open Link"


def title_from_anchor(a):
    text = clean_title(a.get_text(" ", strip=True))
    if not text:
        text = clean_title(a.get("title", "")) or clean_title(a.get("aria-label", ""))
    return text or "Open Link"


def previous_inline_text_before_anchor(a):
    parts = []
    for sibling in a.previous_siblings:
        if getattr(sibling, "name", None) == "br":
            break
        txt = sibling.get_text(" ", strip=True) if hasattr(sibling, "get_text") else str(sibling)
        txt = clean_title(txt)
        if txt:
            parts.insert(0, txt)
    return clean_title(" ".join(parts))


def extract_anchor_item_title(a):
    """Fallback title extraction for a single anchor."""
    anchor_text = title_from_anchor(a)
    prefix = previous_inline_text_before_anchor(a)
    if prefix and anchor_text:
        return clean_title(prefix + " " + anchor_text).strip(" -")
    return anchor_text.strip(" -")


def _release_description(text):
    text = clean_title(text)
    if not text:
        return ""
    # Release labels are useful metadata, but should never replace the movie title.
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"(?i)\s*\[W\]\s*", " ", text)
    text = text.strip(" -–—")
    return clean_title(text)


def _row_title_without_links(fragment):
    """Read plain title text from a row while excluding linked release labels."""
    try:
        from copy import deepcopy
        clone = BeautifulSoup(str(fragment), "html.parser")
        for a in clone.select("a"):
            a.decompose()
        text = clean_title(clone.get_text(" ", strip=True))
        text = re.sub(r"\s+", " ", text).strip(" -–—")
        text = re.sub(r"(?:\s*[-–—]\s*)+$", "", text).strip()
        return text
    except Exception:
        return ""


def _is_noise_title(text):
    raw = clean_title(text)
    # A bracketed resolution/codec/size label is metadata, not a movie title.
    if re.match(r"^\[.*\]$", raw) and re.search(r"(?i)(\d{3,4}p|4k|hevc|x26[45]|avc|aac|gb|mb|rip)", raw):
        return True
    value = raw.strip(" [](){}-–—")
    low = value.casefold()
    if not value or low in {"w", "open", "link", "download", "watch", "click here"}:
        return True
    return False


def _iter_content_rows(widget):
    """Split forum widget content into visual rows, normally separated by <br>."""
    content = widget.select_one(".cPost_contentWrap [data-role='commentContent']")
    if content is None:
        content = widget
    raw = str(content)
    parts = re.split(r"<br\s*/?\s*>", raw, flags=re.I)
    rows = []
    for part in parts:
        if not BeautifulSoup(part, "html.parser").select("a[href]"):
            continue
        rows.append(BeautifulSoup(part, "html.parser"))
    # If no line breaks existed, keep the legacy per-anchor fallback rather than
    # merging an entire widget into a single title.
    if len(parts) == 1:
        rows = []
        for a in content.select("strong a[href]"):
            rows.append(a.parent if getattr(a, "parent", None) else a)
    return rows


def _row_item(row):
    anchors = row.select("a[href]")
    valid = []
    for a in anchors:
        href = (a.get("href") or "").strip()
        if not href or href.startswith(("mailto:", "#", "javascript:")):
            continue
        valid.append(a)
    if not valid:
        return None

    title = _row_title_without_links(row)
    if _is_noise_title(title):
        title = ""
    if not title:
        # Prefer a same-site topic title if the anchor text itself is meaningful.
        for a in valid:
            candidate = title_from_anchor(a).strip(" [](){}-–—")
            if not _is_noise_title(candidate):
                title = candidate
                break
    if not title:
        return None

    links = []
    subtitle_parts = []
    for a in valid:
        href = (a.get("href") or "").strip()
        label = title_from_anchor(a)
        links.append({"label": label or "Open", "url": href})
        if label and label != title:
            # Keep resolution/codec text as secondary card metadata, but suppress
            # the short [W] host marker from both title and subtitle.
            normalized_label = clean_title(label).strip(" [](){}-–—").casefold()
            if normalized_label not in {"w", "open", "link", "download", "watch"}:
                subtitle_parts.append(label.strip())
    subtitle = " · ".join(dict.fromkeys(subtitle_parts))
    # Never expose a lone [W] as the movie card title.
    return {"title": title, "subtitle": subtitle, "links": links}


def extract_sections(soup):
    """Extract sections while grouping each br-separated movie row into one card.

    For rows like `Movie (2026) -ESub [1080p ...] [W]`, the non-link text is the
    title and all associated links remain available when the card is opened.
    """
    sections = []
    widgets = soup.select("li.ipsWidget")
    for widget in widgets:
        header = widget.select_one(".banger-header")
        if not header:
            continue
        section_title = clean_title(header.get_text(" ", strip=True))
        if not section_title:
            continue
        items = []
        seen = set()
        for row in _iter_content_rows(widget):
            item = _row_item(row)
            if not item:
                continue
            # Avoid treating generic [W] host links as independent titles.
            key = (item["title"].casefold(), tuple(link["url"] for link in item["links"]))
            if key in seen:
                continue
            seen.add(key)
            items.append(item)
        # Fallback for widget structures without br-delimited rows.
        if not items:
            for a in widget.select("strong a[href]"):
                href = (a.get("href") or "").strip()
                title = extract_anchor_item_title(a)
                if not href or _is_noise_title(title):
                    continue
                key = (title.casefold(), href)
                if key in seen:
                    continue
                seen.add(key)
                items.append({"title": title, "subtitle": "", "links": [{"label": title_from_anchor(a), "url": href}]})
        if items:
            sections.append({"title": section_title, "items": items})
    return sections


def title_from_dn(magnet):
    parsed = urllib.parse.urlparse(magnet)
    query = urllib.parse.parse_qs(parsed.query)
    dn = query.get("dn", [""])[0]
    if dn:
        return clean_title(urllib.parse.unquote_plus(dn).replace(".", " ").replace("_", " "))
    return ""


def simplify_quality_title(full_title, magnet=""):
    text = clean_title(full_title).replace(".torrent", "")
    # Normalize spaces and separators.
    text = re.sub(r"\s+", " ", text).strip(" :-")

    # Prefer explicit quality + size from full title.
    quality_match = re.search(r"(?i)(2160p|4k|1080p|720p|480p|360p)", text)
    size_match = re.search(r"(?i)(\d+(?:\.\d+)?\s*(?:GB|MB))", text)
    if quality_match and size_match:
        return clean_title(quality_match.group(1) + " - " + size_match.group(1))
    if quality_match:
        return clean_title(quality_match.group(1))
    if size_match:
        return clean_title(size_match.group(1))

    # Fallback to dn= when title text is not useful.
    dn = title_from_dn(magnet)
    if dn:
        quality_match = re.search(r"(?i)(2160p|4k|1080p|720p|480p|360p)", dn)
        size_match = re.search(r"(?i)(\d+(?:\.\d+)?\s*(?:GB|MB))", dn)
        if quality_match and size_match:
            return clean_title(quality_match.group(1) + " - " + size_match.group(1))
        if quality_match:
            return clean_title(quality_match.group(1))
        if size_match:
            return clean_title(size_match.group(1))

    return dn or "Magnet Link"


def get_magnet_full_title_from_previous_nodes(magnet_tag):
    current = magnet_tag.previous_element
    while current:
        if getattr(current, "name", None) == "strong":
            text = clean_title(current.get_text(" ", strip=True))
            lower = text.lower()
            if (
                text
                and "telegram" not in lower
                and "official" not in lower
                and "click here" not in lower
                and "torrent" not in lower
                and "direct link" not in lower
                and len(text) > 5
            ):
                return text
        current = current.previous_element
    return ""


def extract_magnets_from_page(soup, final_url):
    page_art = get_page_image(soup, final_url)
    magnets = []
    seen = set()

    content = soup.select_one(".cPost_contentWrap [data-role='commentContent']")
    search_area = content if content else soup

    for a in search_area.select('a[href^="magnet:"]'):
        magnet = a.get("href", "").strip()
        if not magnet or magnet in seen:
            continue
        seen.add(magnet)

        full_title = get_magnet_full_title_from_previous_nodes(a)
        if not full_title:
            full_title = title_from_dn(magnet)
        title = simplify_quality_title(full_title, magnet)

        magnets.append({"title": title, "magnet": magnet, "art": page_art})

    return magnets


def get_recently_played():
    try:
        return _load_cache_store().get("recently_played", [])[:MAX_RECENTLY_PLAYED]
    except Exception:
        return []


def remember_played(title, magnet, art=""):
    title = clean_title(title) or title_from_dn(magnet) or "Recently Played"
    if not magnet:
        return
    store = _load_cache_store()
    history = [x for x in store.get("recently_played", []) if x.get("magnet") != magnet]
    history.insert(0, {"title": title, "magnet": magnet, "art": art or "", "time": int(time.time())})
    store["recently_played"] = history[:MAX_RECENTLY_PLAYED]
    _save_cache_store(store)


def play_magnet(magnet, title="", art=""):
    if not magnet or not magnet.startswith("magnet:"):
        xbmcgui.Dialog().notification("Playback", "Invalid magnet link", xbmcgui.NOTIFICATION_ERROR, 3000)
        li = xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(HANDLE, False, li)
        return
    remember_played(title, magnet, art)
    elementum_url = "plugin://plugin.video.elementum/play?uri=" + urllib.parse.quote(magnet, safe="")
    li = xbmcgui.ListItem(label=title or title_from_dn(magnet))
    li.setPath(elementum_url)
    li.setProperty("IsPlayable", "true")
    if art:
        set_art(li, art)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def launch_magnet(magnet, title="", art=""):
    # Route playback through this add-on so history is only recorded when selected.
    target = make_url({"action": "play_magnet", "magnet": magnet, "title": title, "art": art})
    xbmc.executebuiltin("PlayMedia(" + target + ")")


def choose_magnet_and_play(magnets, movie_title=""):
    if not magnets:
        return False
    if len(magnets) == 1:
        chosen = magnets[0]
    else:
        entries = []
        for magnet in magnets:
            label = clean_title(magnet.get("title", "")) or "Release"
            # Include an explicit size when it is available from the magnet metadata.
            dn = title_from_dn(magnet.get("magnet", ""))
            size = re.search(r"(?i)(\d+(?:\.\d+)?\s*(?:GB|MB))", dn + " " + label)
            if size and size.group(1).lower() not in label.lower():
                label += " · " + size.group(1).upper()
            entries.append({
                "label": label,
                "kind": "magnet",
                "magnet": magnet.get("magnet", ""),
                "title": movie_title or magnet.get("title", ""),
                "art": magnet.get("art", "")
            })
        window = ExampleGaneshReleaseWindow(
            "exampleganesh-release.xml",
            xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
            "Default", "1080i"
        )
        window.set_start(
            movie_title or "SELECT A RELEASE",
            magnets[0].get("art", ""),
            entries,
            "",
            subtitle="Choose a release to play"
        )
        window.doModal()
        selected = window._selected
        del window
        if not selected:
            return False
        return True
    launch_magnet(chosen.get("magnet", ""), movie_title or chosen.get("title", ""), chosen.get("art", ""))
    return True


def list_recently_played():
    configure_browse_ui("Recently Watched")
    history = get_recently_played()
    for entry in history:
        add_magnet(entry.get("title", "Recently Played"), entry.get("magnet", ""), entry.get("art", ""))
    if not history:
        li = xbmcgui.ListItem(label="Your recently played titles will appear here")
        xbmcplugin.addDirectoryItem(HANDLE, make_url({"action": "recent"}), li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def _list_home_directory():
    configure_browse_ui("Moviez · Home")
    # Build a Kodi-native streaming-style landing page. The active Kodi skin
    # controls the actual hero/carousel layout; artwork is supplied for skin use.
    add_folder("Recently Watched · Last 20 Played", "recent", art="DefaultRecentlyAdded.png")
    try:
        html, final_url = get_html(get_base_url())
        soup = BeautifulSoup(html, "html.parser")
        sections = extract_sections(soup)
        top_index = next((i for i, sec in enumerate(sections)
                          if "top releases this week" in sec["title"].casefold()), None)
        if top_index is None:
            top_index = next((i for i, sec in enumerate(sections)
                              if "top release" in sec["title"].casefold()), None)
        if top_index is not None:
            section = sections[top_index]
            featured = section["items"]
            arts = fetch_visible_artwork(featured, final_url, get_page_image(soup, final_url))
            # Featured titles are ordinary Kodi directory items, retaining the proven
            # v1.8.5 item route and per-title artwork assignment.
            for i, item in enumerate(featured):
                add_folder("★  " + item["title"], "item", final_url,
                           section_index=top_index, item_index=i, art=arts[i], label2=section["title"])
            add_folder("Top Releases This Week · Browse All", "section", final_url, section_index=top_index,
                       art=arts[0] if arts else get_page_image(soup, final_url))
        else:
            # If the source labels the section differently, retain all existing sections.
            add_folder("Browse Website", "open", get_base_url())
        # Link to the source's real Recently Added section when it exists; do not
        # invent titles or alter the established paginated section renderer.
        recent_added_index = next((i for i, sec in enumerate(sections)
                                   if "recently added" in sec["title"].casefold()
                                   or "latest added" in sec["title"].casefold()), None)
        if recent_added_index is not None:
            recent_section = sections[recent_added_index]
            recent_art = get_page_image(soup, final_url)
            # Render only the first page of Recently Added on the landing page.
            # The full section remains available below and retains on-demand paging.
            recent_visible = recent_section["items"][:ITEMS_PER_PAGE]
            recent_arts = fetch_visible_artwork(recent_visible, final_url, recent_art)
            for recent_item_index, recent_item in enumerate(recent_visible):
                add_folder(recent_item["title"], "item", final_url,
                           section_index=recent_added_index, item_index=recent_item_index,
                           art=recent_arts[recent_item_index],
                           label2=recent_item.get("subtitle", ""))
            add_folder("Recently Added · Browse All", "section", final_url,
                       section_index=recent_added_index, art=recent_art,
                       label2=recent_section["title"])
        add_folder("Browse All Sections", "open", get_base_url(), art=get_page_image(soup, final_url))
    except Exception as e:
        xbmc.log("ExampleGanesh home discovery warning: " + str(e), xbmc.LOGWARNING)
        add_folder("Browse Website", "open", get_base_url())
    add_search_entry()
    add_folder("Website Setup", "setup", art="DefaultUser.png")
    add_folder("Clear Cache", "clear_cache", art="DefaultAddonService.png")
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()




def _overlay_entries_for_url(url, movie_title="", art="", section_index=None, item_index=None):
    """Build entries for the modal browser without opening Kodi's Videos directory."""
    html, final_url = get_html(url)
    soup = BeautifulSoup(html, "html.parser")
    page_art = get_page_image(soup, final_url) or art or ""
    magnets = extract_magnets_from_page(soup, final_url)
    if magnets:
        return [{"label": m.get("title") or "Release", "kind": "magnet",
                 "magnet": m.get("magnet", ""), "title": movie_title or m.get("title", ""),
                 "art": m.get("art") or page_art} for m in magnets if m.get("magnet")]

    sections = extract_sections(soup)
    entries = []
    if section_index is not None:
        try:
            section = sections[int(section_index)]
        except (IndexError, ValueError, TypeError):
            section = None
        if section is not None and item_index is None:
            for raw_index, item in enumerate(section.get("items", [])):
                label = clean_title(item.get("title", "")) or "Open title"
                if label in ("..", ".", "Parent directory") or _is_noise_title(label):
                    continue
                entries.append({"label": label, "kind": "item", "url": final_url,
                                "section_index": int(section_index), "item_index": raw_index,
                                "title": label, "art": page_art})
            if entries:
                return entries
        if section is not None and item_index is not None:
            try:
                item = section.get("items", [])[int(item_index)]
            except (IndexError, ValueError, TypeError):
                item = None
            if item is not None:
                title = clean_title(item.get("title", "")) or movie_title or "Selected title"
                for link in item.get("links", []):
                    label = clean_title(link.get("label", "")) or title
                    href = link.get("url", "")
                    full_url = urllib.parse.urljoin(final_url, href)
                    if full_url.startswith("magnet:"):
                        entries.append({"label": label, "kind": "magnet", "magnet": full_url,
                                        "title": title, "art": page_art})
                    elif full_url.startswith("http") and is_allowed_url(full_url):
                        entries.append({"label": label, "kind": "page", "url": full_url,
                                        "title": title, "art": page_art})
                if entries:
                    return entries

    # If the page itself has sections, let the user drill into them in the same overlay.
    for idx, section in enumerate(sections):
        label = clean_title(section.get("title", "")) or "Browse section"
        if label and not _is_noise_title(label):
            entries.append({"label": label, "kind": "section", "url": final_url,
                            "section_index": idx, "title": movie_title or label, "art": page_art})
    if entries:
        return entries

    # Fallback: display useful allowed links from a page that isn't covered by the site's section parser.
    seen = set()
    for a in soup.select("a[href]"):
        href = (a.get("href") or "").strip()
        full_url = urllib.parse.urljoin(final_url, href)
        label = clean_title(a.get_text(" ", strip=True)) or "Open link"
        if (full_url.startswith("http") and is_allowed_url(full_url)
                and full_url not in seen and not _is_noise_title(label)
                and label.lower() not in ("home", "login", "register", "next", "previous")):
            seen.add(full_url)
            entries.append({"label": label, "kind": "page", "url": full_url,
                            "title": movie_title or label, "art": page_art})
    return entries[:80]


class ExampleGaneshReleaseWindow(xbmcgui.WindowXMLDialog):
    """Centered release/browser overlay; parent cinematic homepage remains open underneath."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._stack = []
        self._movie_title = ""
        self._art = ""
        self._selected = False
        self._mode = "browse"
        self._choice = None
        self._setup_data = None
        self._defer_playback = False
        self._play_request = None

    def set_start(self, title, art, entries, url, section_index=None, item_index=None,
                  subtitle="Choose a source to continue", mode="browse", setup_data=None,
                  defer_playback=False):
        self._movie_title = title or "Selected title"
        self._art = art or ""
        self._selected = False
        self._choice = None
        self._mode = mode
        self._setup_data = dict(setup_data or {}) if mode == "setup" else None
        self._defer_playback = bool(defer_playback)
        self._play_request = None
        self._stack = [{
            "heading": self._movie_title,
            "subtitle": subtitle,
            "entries": entries,
            "url": url,
            "section_index": section_index,
            "item_index": item_index
        }]

    def onInit(self):
        self._render()

    def _render(self):
        current = self._stack[-1]
        self.getControl(900).setLabel(current.get("heading", "SELECT A RELEASE"))
        self.getControl(901).setLabel(current.get("subtitle", "Choose a source to continue"))
        control = self.getControl(902)
        control.reset()
        items = []
        for entry in current.get("entries", []):
            li = xbmcgui.ListItem(label=entry.get("label", "Open"))
            for key, value in entry.items():
                if value is not None:
                    li.setProperty("eg_" + key, str(value))
            items.append(li)
        control.addItems(items)
        if items:
            self.setFocusId(902)
        else:
            self.getControl(901).setLabel("No releases or links were found on this page.")

    def _push(self, heading, entries, url, section_index=None, item_index=None):
        self._stack.append({
            "heading": heading or "BROWSE",
            "subtitle": "Choose a source to continue",
            "entries": entries,
            "url": url,
            "section_index": section_index,
            "item_index": item_index
        })
        self._render()

    def _open_page(self, url, title, section_index=None, item_index=None):
        try:
            entries = _overlay_entries_for_url(url, title, self._art, section_index, item_index)
            if not entries:
                xbmcgui.Dialog().notification("ExampleGanesh", "No releases or links found", xbmcgui.NOTIFICATION_INFO, 2500)
                return
            has_magnets = any(e.get("kind") == "magnet" for e in entries)
            heading = title or "BROWSE"
            self._push(heading, entries, url, section_index, item_index)
        except Exception as e:
            xbmc.log("ExampleGanesh release overlay error: " + str(e), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("ExampleGanesh", "Could not load this page", xbmcgui.NOTIFICATION_ERROR, 3000)

    def _refresh_setup_entries(self, message=None):
        current = self._stack[-1]
        for entry in current.get("entries", []):
            if entry.get("kind") == "setup_url":
                entry["label"] = "WEBSITE URL   ·   " + self._setup_data.get("base_url", "")
            elif entry.get("kind") == "setup_domain":
                entry["label"] = "ALLOWED DOMAIN   ·   " + self._setup_data.get("allowed_domain", "")
        if message:
            current["subtitle"] = message
        self._render()

    def _handle_setup_choice(self, kind):
        if kind == "setup_url":
            value = xbmcgui.Dialog().input(
                "Website URL",
                defaultt=self._setup_data.get("base_url", DEFAULT_BASE_URL),
                type=xbmcgui.INPUT_ALPHANUM
            )
            if not value:
                self.close()
                return
            value = value.strip()
            if not value:
                self.close()
                return
            self._setup_data["base_url"] = value
            parsed_domain = urllib.parse.urlparse(value).netloc.lower().replace("www.", "")
            self._setup_data["allowed_domain"] = parsed_domain or self._setup_data.get("allowed_domain", DEFAULT_ALLOWED_DOMAIN)
            self._refresh_setup_entries("Website URL updated. Review the domain, then save.")
        elif kind == "setup_domain":
            parsed_domain = urllib.parse.urlparse(
                self._setup_data.get("base_url", "")
            ).netloc.lower().replace("www.", "")
            default_domain = parsed_domain or self._setup_data.get("allowed_domain", DEFAULT_ALLOWED_DOMAIN)
            value = xbmcgui.Dialog().input(
                "Allowed Domain",
                defaultt=default_domain,
                type=xbmcgui.INPUT_ALPHANUM
            )
            self._setup_data["allowed_domain"] = (value.strip().lower() if value else default_domain)
            self._refresh_setup_entries("Allowed domain updated. Save to apply your settings.")
        elif kind == "setup_save":
            saved = save_config({
                "base_url": self._setup_data.get("base_url", DEFAULT_BASE_URL),
                "allowed_domain": self._setup_data.get("allowed_domain", DEFAULT_ALLOWED_DOMAIN).strip().lower()
            })
            message = ("Website settings saved successfully." if saved
                       else "Could not save website settings. Please try again.")
            self._refresh_setup_entries(message)
        elif kind == "setup_cancel":
            self.close()

    def onClick(self, control_id):
        if control_id != 902:
            return
        try:
            li = self.getControl(902).getSelectedItem()
            if not li:
                return
            kind = li.getProperty("eg_kind")
            title = li.getProperty("eg_title") or self._movie_title
            art = li.getProperty("eg_art") or self._art
            if self._mode == "search":
                if kind == "search_new":
                    self._choice = ("new", "")
                    self.close()
                elif kind == "search_recent":
                    self._choice = ("recent", li.getProperty("eg_term"))
                    self.close()
                return
            if self._mode == "setup":
                self._handle_setup_choice(kind)
                return
            if kind == "magnet":
                magnet = li.getProperty("eg_magnet")
                if magnet:
                    self._selected = True
                    if self._defer_playback:
                        self._play_request = (magnet, title, art)
                        self.close()
                    else:
                        self.close()
                        launch_magnet(magnet, title, art)
                return
            url = li.getProperty("eg_url")
            section_index = li.getProperty("eg_section_index")
            item_index = li.getProperty("eg_item_index")
            if kind == "section":
                self._open_page(url, title, int(section_index), None)
            elif kind == "item":
                self._open_page(url, title, int(section_index), int(item_index))
            elif kind == "page":
                self._open_page(url, title)
        except Exception as e:
            xbmc.log("ExampleGanesh release overlay selection error: " + str(e), xbmc.LOGERROR)
            xbmcgui.Dialog().notification("ExampleGanesh", "Could not open selected entry", xbmcgui.NOTIFICATION_ERROR, 3000)

    def onAction(self, action):
        try:
            if action.getId() in (9, 10, 92, 216):
                if len(self._stack) > 1:
                    self._stack.pop()
                    self._render()
                else:
                    self.close()
        except Exception as e:
            xbmc.log("ExampleGanesh release overlay action error: " + str(e), xbmc.LOGWARNING)


def open_home_title_overlay(target, title, art=""):
    """Resolve a home card into the custom modal browser without leaving the homepage."""
    params = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(target).query))
    url = params.get("url", get_base_url())
    action = params.get("action", "")
    section_index = params.get("section_index")
    item_index = params.get("item_index")
    if action != "item":
        # Other home actions retain their original behavior.
        return False
    entries = _overlay_entries_for_url(
        url, title, art,
        int(section_index) if section_index not in (None, "") else None,
        int(item_index) if item_index not in (None, "") else None
    )
    if not entries:
        xbmcgui.Dialog().notification("ExampleGanesh", "No releases or links found", xbmcgui.NOTIFICATION_INFO, 2500)
        return True
    window = ExampleGaneshReleaseWindow(
        "exampleganesh-release.xml",
        xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
        "Default", "1080i"
    )
    window.set_start(title, art, entries, url, section_index, item_index,
                     defer_playback=True)
    window.doModal()
    play_request = window._play_request
    del window
    if play_request:
        return {"playback": play_request}
    return True



class ExampleGaneshHomeWindow(xbmcgui.WindowXMLDialog):
    """Option A: full-screen cinematic hero pages with explicit toolbar/section navigation."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.featured_items = []
        self.added_items = []
        self.watched_items = []
        self._targets = {}
        self._section_id = 110
        self._pan_control = None
        self._pan_stop_event = threading.Event()
        self._pan_lock = threading.Lock()
        self._pan_active = False
        self._pan_distance = 0
        self._pan_started = 0.0
        self._pan_thread = None
        self._last_user_interaction = time.monotonic()
        self._auto_scroll_suspended = False
        self._auto_scroll_cooldown_until = 0.0
        self._auto_scroll_cursor_section = None
        self._auto_scroll_cursor = None
        self.resume_state = None
        self._playback_request = None
        self._resume_state = None

    def onInit(self):
        try:
            self._note_user_interaction()
            self._pan_control = self.getControl(100)
            self._pan_thread = threading.Thread(
                target=self._pan_loop, name="MoviezPosterPan", daemon=True
            )
            self._pan_thread.start()
            self.getControl(110).addItems(self.featured_items)
            self.getControl(120).addItems(self.added_items)
            if self.watched_items:
                self.getControl(130).addItems(self.watched_items)
            else:
                self.watched_items = []
            saved_indices = (self.resume_state or {}).get("indices", {})
            saved_targets = (self.resume_state or {}).get("targets", {})
            for cid in (110, 120, 130):
                items = {110: self.featured_items, 120: self.added_items,
                         130: self.watched_items}.get(cid, [])
                if items:
                    try:
                        saved_index = int(saved_indices.get(str(cid), 0))
                        saved_target = saved_targets.get(str(cid), "")
                        if saved_target:
                            matching_index = next(
                                (index for index, item in enumerate(items)
                                 if item.getProperty("eg_target") == saved_target),
                                None,
                            )
                            if matching_index is not None:
                                saved_index = matching_index
                        self.getControl(cid).selectItem(max(0, min(saved_index, len(items) - 1)))
                    except Exception:
                        pass
            initial_section = (self.resume_state or {}).get("section_id", 110)
            if initial_section not in (110, 120, 130) or (initial_section == 130 and not self.watched_items):
                initial_section = 110
            self._set_section(initial_section, focus=False)
            try: self.setFocusId(initial_section if self.featured_items else 140)
            except Exception: self.setFocus(self.getControl(initial_section if self.featured_items else 140))
            if not self.featured_items:
                self.getControl(103).setLabel("Featured releases unavailable")
                self.getControl(104).setLabel("")
                self.getControl(105).setLabel("")
                self.getControl(106).setLabel("Check Website Setup and try again.")
        except Exception as e:
            xbmc.log("ExampleGanesh custom home init error: " + str(e), xbmc.LOGERROR)

    def _pan_loop(self):
        """Move the poster through the banner and smoothly reverse at each end."""
        leg_seconds = HERO_PAN_LEG_SECONDS
        while not self._pan_stop_event.is_set():
            try:
                with self._pan_lock:
                    active = self._pan_active
                    distance = self._pan_distance
                    started = self._pan_started
                now = time.monotonic()
                if active and self._pan_control is not None:
                    phase = (now - started) % (2.0 * leg_seconds)
                    leg = phase / leg_seconds if phase <= leg_seconds else (2.0 * leg_seconds - phase) / leg_seconds
                    eased = (1.0 - math.cos(math.pi * leg)) / 2.0
                    y = 124 - int(round(distance * eased))
                    self._pan_control.setPosition(180, y)
                self._maybe_auto_scroll(now, started, distance)
            except Exception as e:
                xbmc.log("ExampleGanesh poster pan warning: " + str(e), xbmc.LOGWARNING)
                with self._pan_lock:
                    self._pan_active = False
            xbmc.sleep(33)

    def _note_user_interaction(self):
        with self._pan_lock:
            self._last_user_interaction = time.monotonic()
            self._auto_scroll_cooldown_until = 0.0
            self._auto_scroll_cursor_section = None
            self._auto_scroll_cursor = None

    def _maybe_auto_scroll(self, now, pan_started, pan_distance):
        with self._pan_lock:
            last_interaction = self._last_user_interaction
            section_id = self._section_id
            suspended = self._auto_scroll_suspended
            cooldown_until = self._auto_scroll_cooldown_until
            cursor_section = self._auto_scroll_cursor_section
            cursor = self._auto_scroll_cursor
        if suspended or now < cooldown_until:
            return
        idle_deadline = last_interaction + HOME_AUTO_SCROLL_IDLE_SECONDS
        if now < idle_deadline:
            return

        items = {110: self.featured_items, 120: self.added_items,
                 130: self.watched_items}.get(section_id, [])
        auto_positions = [index for index, item in enumerate(items)
                          if item.getProperty("eg_auto_scroll") != "false"]
        if len(auto_positions) < 2:
            return

        if pan_distance > 0:
            cycle_seconds = HERO_PAN_LEG_SECONDS
            cycles = max(1, int(math.ceil((idle_deadline - pan_started) / cycle_seconds - 1e-9)))
            advance_at = pan_started + cycles * cycle_seconds
        else:
            # A title without a portrait pan still gets a full, readable dwell.
            advance_at = max(idle_deadline, pan_started + HOME_AUTO_SCROLL_IDLE_SECONDS)
        if now < advance_at:
            return

        try:
            if self.getFocusId() != section_id:
                return
            control = self.getControl(section_id)
            if cursor_section == section_id and cursor in auto_positions:
                current = cursor
            else:
                current = control.getSelectedPosition()
            try:
                current_index = auto_positions.index(current)
                next_position = auto_positions[(current_index + 1) % len(auto_positions)]
            except ValueError:
                next_position = auto_positions[0]

            # Recheck after reading the list so a just-arrived remote action
            # cancels a pending automatic move.
            with self._pan_lock:
                if (self._auto_scroll_suspended or self._section_id != section_id or
                        time.monotonic() - self._last_user_interaction < HOME_AUTO_SCROLL_IDLE_SECONDS):
                    return
                interaction_at_select = self._last_user_interaction
                min_dwell = HERO_PAN_LEG_SECONDS if pan_distance > 0 else HOME_AUTO_SCROLL_IDLE_SECONDS
                self._auto_scroll_cooldown_until = time.monotonic() + min_dwell
            control.selectItem(next_position)
            # Kodi applies the list selection asynchronously. Match the manual
            # navigation delay before reading the selected item for the banner.
            xbmc.sleep(80)
            selected_position = control.getSelectedPosition()
            with self._pan_lock:
                if (self._auto_scroll_suspended or self._section_id != section_id or
                        self._last_user_interaction != interaction_at_select):
                    return
                self._auto_scroll_cursor_section = section_id
                self._auto_scroll_cursor = selected_position
            if self.getFocusId() == section_id and selected_position in auto_positions:
                self._update_hero()
        except Exception as e:
            xbmc.log("ExampleGanesh home auto-scroll warning: " + str(e), xbmc.LOGWARNING)

    def _start_pan(self, distance):
        if self._pan_control is None:
            self._pan_control = self.getControl(100)
        with self._pan_lock:
            self._pan_distance = max(0, int(distance))
            self._pan_started = time.monotonic()
            self._pan_active = self._pan_distance > 0
            self._pan_control.setPosition(180, 124)

    def _stop_pan(self):
        with self._pan_lock:
            self._pan_active = False

    def stop_pan_animation(self):
        self._pan_stop_event.set()
        thread = self._pan_thread
        if thread and thread.is_alive():
            thread.join(timeout=0.5)

    def get_resume_state(self):
        indices = {}
        targets = {}
        for cid in (110, 120, 130):
            try:
                control = self.getControl(cid)
                indices[str(cid)] = control.getSelectedPosition()
                item = control.getSelectedItem()
                targets[str(cid)] = item.getProperty("eg_target") if item else ""
            except Exception:
                indices[str(cid)] = 0
                targets[str(cid)] = ""
        return {"section_id": self._section_id, "indices": indices, "targets": targets}

    def _set_section(self, control_id, focus=True):
        if control_id == 130 and not self.watched_items:
            control_id = 120
        self._section_id = control_id
        for cid in (110, 120, 130):
            try: self.getControl(cid).setVisible(cid == control_id)
            except Exception: pass
        labels = {110: "TOP RELEASES THIS WEEK", 120: "RECENTLY ADDED", 130: "RECENTLY WATCHED"}
        try: self.getControl(151).setLabel(labels.get(control_id, "MOVIEZ"))
        except Exception: pass
        if focus:
            try: self.setFocusId(control_id)
            except Exception: self.setFocus(self.getControl(control_id))
        self._update_hero()

    def _update_hero(self):
        try:
            item = self.getControl(self._section_id).getSelectedItem()
            if not item:
                self._stop_pan()
                return
            poster = item.getArt("poster") or item.getArt("thumb") or ""
            # Pan the portrait poster in the banner; retain landscape fanart as fallback.
            fanart = item.getProperty("eg_fanart") or ""
            bg = os.path.join(xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                              "resources", "skins", "Default", "1080i", "eg-premium-gradient.png")
            pan_control = self.getControl(100)
            fallback_control = self.getControl(166)
            if poster:
                # Size the image to the banner width so the pan can cover the
                # full source image instead of repeatedly cropping its center.
                dimensions = _poster_dimensions(poster)
                source_width, source_height = dimensions or (2, 3)
                banner_width, banner_height = 1560, 430
                pan_height = max(banner_height, int(round(float(banner_width) * source_height / source_width)))
                travel = pan_height - banner_height
                pan_control.setPosition(180, 124)
                pan_control.setWidth(banner_width)
                pan_control.setHeight(pan_height)
                pan_control.setImage(poster)
                pan_control.setVisible(True)
                fallback_control.setVisible(False)
                self._start_pan(travel)
            else:
                self._start_pan(0)
                pan_control.setVisible(False)
                fallback_control.setImage(fanart or bg)
                fallback_control.setVisible(True)
            self.getControl(101).setImage(poster or "")
            title = item.getLabel() or ""
            description = item.getProperty("eg_description") or ""
            year_source, technical, languages = _hero_metadata(title, description)
            self.getControl(103).setLabel(title)
            self.getControl(104).setLabel(year_source)
            self.getControl(105).setLabel(technical)
            self.getControl(106).setLabel(languages)
        except Exception as e:
            xbmc.log("ExampleGanesh hero update warning: " + str(e), xbmc.LOGWARNING)

    def onFocus(self, control_id):
        try:
            self._note_user_interaction()
            if control_id in (110, 120, 130):
                self._section_id = control_id
                labels = {110: "TOP RELEASES THIS WEEK", 120: "RECENTLY ADDED", 130: "RECENTLY WATCHED"}
                self.getControl(151).setLabel(labels.get(control_id, "MOVIEZ"))
                self._update_hero()
        except Exception as e:
            xbmc.log("ExampleGanesh featured focus warning: " + str(e), xbmc.LOGWARNING)

    def onAction(self, action):
        """Explicitly route Kodi Up/Down actions through toolbar and all sections."""
        try:
            self._note_user_interaction()
            aid = action.getId()
            focus = self.getFocusId()
            section_ids = (110, 120, 130)
            toolbar_ids = (140, 141, 142)
            # Kodi can report a stale focus ID while overlapping carousel
            # controls are being shown/hidden. _section_id tracks the visible row.
            active_section = self._section_id

            # Kodi action IDs: 3 = Up, 4 = Down. Handle explicitly because
            # list-control XML onup/ondown can be ignored by horizontal lists.
            if aid == 3:
                # Toolbar is a navigation stop: Up from Top Releases reaches Search,
                # then the user can move left/right across Search, Website Setup, Cache.
                if focus in (140, 141, 142):
                    return
                if active_section == 130:
                    self._set_section(120)
                    return
                if active_section == 120:
                    self._set_section(110)
                    return
                if active_section == 110:
                    self.setFocusId(140)
                    return

            if aid == 4:
                if focus in toolbar_ids:
                    self._set_section(110)
                    return
                if active_section == 110:
                    self._set_section(120)
                    return
                if active_section == 120:
                    if self.watched_items:
                        self._set_section(130)
                    return
                if active_section == 130:
                    # Recently Watched is the bottom navigation endpoint.
                    return

            if aid in (1, 2) and focus in section_ids:
                xbmc.sleep(80)
                self._update_hero()
            elif focus in section_ids:
                self._update_hero()
            if aid in (9, 10, 92, 216):
                self.close()
        except Exception as e:
            xbmc.log("ExampleGanesh remote navigation warning: " + str(e), xbmc.LOGWARNING)

    def _navigate(self, target):
        if not target: return
        safe_target = target.replace('"', '').replace("\\", "")
        self.close()
        xbmc.sleep(350)
        try: xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % safe_target)
        except Exception as e: xbmc.log("ExampleGanesh home navigation error: " + str(e), xbmc.LOGERROR)

    def onClick(self, control_id):
        self._note_user_interaction()
        with self._pan_lock:
            self._auto_scroll_suspended = True
        try:
            self._handle_click(control_id)
        finally:
            with self._pan_lock:
                self._auto_scroll_suspended = False
                self._last_user_interaction = time.monotonic()

    def _handle_click(self, control_id):
        if control_id in (110, 120, 130):
            try:
                item = self.getControl(control_id).getSelectedItem()
                if item:
                    target = item.getProperty("eg_target")
                    title = item.getLabel()
                    art = item.getArt("poster") or item.getArt("thumb") or ""
                    target_params = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(target).query))
                    if target_params.get("action") == "play_magnet":
                        self._playback_request = (
                            target_params.get("magnet", ""),
                            target_params.get("title", title),
                            target_params.get("art", art),
                        )
                        if self._playback_request[0]:
                            self._resume_state = self.get_resume_state()
                            self.close()
                            return
                    handled = open_home_title_overlay(target, title, art)
                    if isinstance(handled, dict) and handled.get("playback"):
                        self._playback_request = handled["playback"]
                        self._resume_state = self.get_resume_state()
                        self.close()
                    elif not handled:
                        self._navigate(target)
            except Exception as e: xbmc.log("ExampleGanesh home navigation error: " + str(e), xbmc.LOGERROR)
        elif control_id == 140:
            term = prompt_search()
            if term: self._navigate(make_url({"action": "search", "url": get_base_url(), "term": term}))
        elif control_id == 141:
            website_setup()
        elif control_id == 142:
            clear_cache()


def _hero_metadata(title, description=""):
    """Build compact, non-invented hero metadata from existing scraped text."""
    import re
    raw_title = (title or "").strip()
    raw_desc = (description or "").strip()
    combined = raw_title + " " + raw_desc

    # Extract a year and a release/source hint from the title only.
    year_match = re.search(r"\b(19\d{2}|20\d{2})\b", raw_title)
    year = year_match.group(1) if year_match else ""
    source_match = re.search(r"\b(BluRay|Blu-ray|WEB[- .]?DL|WEBRip|HDRip|HDTV|DVD|CAM|HDCAM)\b", combined, re.I)
    source = source_match.group(1).replace(" ", "") if source_match else ""
    line1 = " · ".join(x for x in (year, source) if x)

    # Only show values that actually exist in the scraped title/subtitle.
    resolutions = []
    for m in re.finditer(r"(?<!\d)(4K|2160p|1080p|720p|480p|360p)(?!\w)", combined, re.I):
        value = m.group(1).upper() if m.group(1).lower() == "4k" else m.group(1).lower()
        if value not in resolutions:
            resolutions.append(value)
    codec_match = re.search(r"\b(x264|x265|H\.?264|H\.?265|AVC|HEVC)\b", combined, re.I)
    codec = codec_match.group(1).upper().replace("H.264", "H.264").replace("H264", "H.264") if codec_match else ""
    size_match = re.search(r"\b(\d+(?:\.\d+)?)\s*(GB|MB)\b", combined, re.I)
    size = (size_match.group(1) + " " + size_match.group(2).upper()) if size_match else ""
    technical = resolutions[:2]
    if codec and codec not in technical: technical.append(codec)
    if size and size not in technical: technical.append(size)

    # Extract language names from common title/subtitle language patterns.
    languages = []
    language_names = ("Tamil", "Telugu", "Hindi", "Malayalam", "Kannada", "English", "Bengali", "Marathi", "Punjabi", "Korean", "Japanese", "Chinese", "Spanish", "French", "Arabic", "Thai", "Urdu")
    for lang in language_names:
        if re.search(r"\b" + re.escape(lang) + r"\b", combined, re.I):
            languages.append(lang)
    if not languages and re.search(r"\bESub\b|\bSubtitles?\b", combined, re.I):
        languages = ["Subtitles"]
    return line1, " · ".join(technical[:4]), " · ".join(languages[:6])


def _home_item(title, art, target, description="", auto_scroll=True):
    item = xbmcgui.ListItem(label=title)
    if art:
        item.setArt({"thumb": art, "icon": art, "poster": art})
    item.setProperty("eg_fanart", art if art and art.lower().endswith((".jpg", ".jpeg", ".png", ".webp")) else "")
    item.setProperty("eg_target", target or "")
    item.setProperty("eg_description", description or "")
    item.setProperty("eg_auto_scroll", "true" if auto_scroll else "false")
    item.setInfo("video", {"title": title, "plot": description or ""})
    return item


class _HomePlaybackWatcher(xbmc.Player):
    """Track the actual Kodi player lifecycle before restoring the home window."""
    def __init__(self):
        super().__init__()
        self.started = threading.Event()
        self.finished = threading.Event()
        self.failed = threading.Event()

    def onPlayBackStarted(self):
        self.started.set()

    def onAVStarted(self):
        self.started.set()

    def onPlayBackEnded(self):
        if self.started.is_set():
            self.finished.set()

    def onPlayBackStopped(self):
        if self.started.is_set():
            self.finished.set()

    def onPlayBackError(self):
        if self.started.is_set():
            self.finished.set()
        else:
            self.failed.set()


def show_custom_home():
    """Load the real site sections and render a remote-friendly home window."""
    html, final_url = get_html(get_base_url())
    soup = BeautifulSoup(html, "html.parser")
    sections = extract_sections(soup)
    page_art = get_page_image(soup, final_url)

    top_index = next((i for i, sec in enumerate(sections)
                      if "top releases this week" in sec["title"].casefold()), None)
    if top_index is None:
        top_index = next((i for i, sec in enumerate(sections)
                          if "top release" in sec["title"].casefold()), None)
    added_index = next((i for i, sec in enumerate(sections)
                        if "recently added" in sec["title"].casefold()
                        or "latest added" in sec["title"].casefold()), None)

    featured_items, added_items, watched_items = [], [], []
    if top_index is not None:
        section = sections[top_index]
        # Keep each item's original index from the unfiltered section. The item
        # route re-reads extract_sections() and expects that original index.
        indexed_items = [(raw_index, entry) for raw_index, entry in enumerate(section["items"])
                         if clean_title(entry.get("title", "")).strip() not in ("..", ".", "Parent directory")
                         and not _is_noise_title(entry.get("title", ""))]
        visible_pairs = indexed_items
        visible = [entry for _, entry in visible_pairs]
        arts = fetch_visible_artwork(visible, final_url, page_art or xbmcaddon.Addon(ADDON_ID).getAddonInfo("icon"))
        for display_index, (raw_index, entry) in enumerate(visible_pairs):
            target = make_url({"action": "item", "url": final_url,
                               "section_index": top_index, "item_index": raw_index})
            featured_items.append(_home_item(
                entry.get("title", "Featured title"), arts[display_index] or xbmcaddon.Addon(ADDON_ID).getAddonInfo("icon"), target,
                entry.get("subtitle", "") or "Select to view available releases."
            ))

    if added_index is not None:
        section = sections[added_index]
        # As above, preserve source indexes so filtered cards still open the
        # matching source item rather than a different title.
        indexed_items = [(raw_index, entry) for raw_index, entry in enumerate(section["items"])
                         if clean_title(entry.get("title", "")).strip() not in ("..", ".", "Parent directory")
                         and not _is_noise_title(entry.get("title", ""))]
        visible_pairs = indexed_items[:ITEMS_PER_PAGE]
        visible = [entry for _, entry in visible_pairs]
        arts = fetch_visible_artwork(visible, final_url, page_art or xbmcaddon.Addon(ADDON_ID).getAddonInfo("icon"))
        for display_index, (raw_index, entry) in enumerate(visible_pairs):
            target = make_url({"action": "item", "url": final_url,
                               "section_index": added_index, "item_index": raw_index})
            added_items.append(_home_item(entry.get("title", "Title"), arts[display_index] or xbmcaddon.Addon(ADDON_ID).getAddonInfo("icon"), target,
                                          entry.get("subtitle", "")))
        added_items.append(_home_item(
            "Browse All Recently Added", page_art,
            make_url({"action": "section", "url": final_url, "section_index": added_index}),
            "Open the complete section with on-demand pagination.", auto_scroll=False
        ))

    def make_watched_items():
        items = []
        for entry in get_recently_played():
            target = make_url({"action": "play_magnet", "magnet": entry.get("magnet", ""),
                               "title": entry.get("title", "Recently Watched"),
                               "art": entry.get("art", "")})
            items.append(_home_item(entry.get("title", "Recently Watched"),
                                    entry.get("art", page_art), target,
                                    "Play this recently watched title again."))
        return items

    watched_items = make_watched_items()

    # Provide graceful fallbacks for websites that use different section headings.
    if not featured_items:
        featured_items.append(_home_item(
            "Browse Website", page_art, make_url({"action": "open", "url": get_base_url()}),
            "Featured releases could not be detected; open the website sections.", auto_scroll=False
        ))
    if not added_items:
        added_items.append(_home_item(
            "Browse All Sections", page_art, make_url({"action": "open", "url": get_base_url()}),
            "Browse the available website sections.", auto_scroll=False
        ))

    # Kodi appends resources/skins/<skin>/<resolution> to scriptPath itself.
    # Pass the add-on root, not the skin directory, or Kodi searches a duplicated path.
    # This is a plugin directory invocation (plugin://.../). Kodi expects the
    # directory handle to be completed even when a custom modal UI is shown.
    # Without this, closing the dialog causes GetDirectory(plugin://...) failed
    # and Kodi may abandon the parent plugin window during click navigation.
    try:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)
    except TypeError:
        # Compatibility with Kodi builds exposing the older Python signature.
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

    resume_state = None
    while True:
        window = ExampleGaneshHomeWindow("exampleganesh-home.xml",
                                         xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                                         "Default", "1080i")
        window.featured_items = featured_items
        window.added_items = added_items
        window.watched_items = watched_items
        window.resume_state = resume_state
        try:
            window.doModal()
            playback_request = window._playback_request
            if playback_request:
                resume_state = window._resume_state or window.get_resume_state()
        finally:
            window.stop_pan_animation()
            del window

        if not playback_request:
            break

        # Close the modal homepage before asking Kodi to open the player. Kodi
        # can otherwise keep a modal dialog above fullscreen playback.
        playback_watcher = _HomePlaybackWatcher()
        launch_magnet(*playback_request)
        monitor = xbmc.Monitor()
        # Elementum can take longer than a short fixed delay to resolve and
        # open a stream. Keep the home dialog closed until Kodi confirms the
        # player started, or reports an error / startup timeout.
        startup_deadline = time.monotonic() + 300.0
        started = False
        while not monitor.abortRequested() and time.monotonic() < startup_deadline:
            if playback_watcher.started.is_set():
                started = True
                break
            if playback_watcher.failed.is_set():
                break
            xbmc.sleep(250)
        if started:
            while not monitor.abortRequested():
                if playback_watcher.finished.is_set():
                    break
                xbmc.sleep(500)
        if monitor.abortRequested():
            break
        watched_items = make_watched_items()


def list_home():
    try:
        show_custom_home()
    except Exception as e:
        xbmc.log("ExampleGanesh custom home unavailable; using directory fallback: " + str(e), xbmc.LOGERROR)
        _list_home_directory()


def website_setup():
    config = load_config()
    setup_data = {
        "base_url": config.get("base_url", DEFAULT_BASE_URL),
        "allowed_domain": config.get("allowed_domain", DEFAULT_ALLOWED_DOMAIN)
    }
    entries = [
        {"label": "WEBSITE URL   ·   " + setup_data["base_url"], "kind": "setup_url"},
        {"label": "ALLOWED DOMAIN   ·   " + setup_data["allowed_domain"], "kind": "setup_domain"},
        {"label": "SAVE WEBSITE SETTINGS", "kind": "setup_save"},
        {"label": "CANCEL", "kind": "setup_cancel"}
    ]
    window = ExampleGaneshReleaseWindow(
        "exampleganesh-release.xml",
        xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
        "Default", "1080i"
    )
    window.set_start(
        "WEBSITE SETUP", "", entries, "",
        subtitle="Select a field to edit, then save your settings",
        mode="setup",
        setup_data=setup_data
    )
    window.doModal()
    del window
    # Do not refresh the container here. When setup is launched from the custom
    # home modal, refreshing the plugin root re-enters list_home and causes a loop.


def get_poster_view_id():
    try:
        value = xbmcaddon.Addon(ADDON_ID).getSetting("poster_view_id")
        return int(value) if value.strip() else DEFAULT_POSTER_VIEW_ID
    except Exception:
        return DEFAULT_POSTER_VIEW_ID


def apply_poster_view():
    """Request the configured poster view for the current Kodi container."""
    try:
        xbmc.executebuiltin("Container.SetViewMode(%d)" % get_poster_view_id())
    except Exception as e:
        xbmc.log("ExampleGanesh poster view warning: %s" % str(e), xbmc.LOGWARNING)


def configure_browse_ui(category="Browse"):
    """Ask Kodi skins for poster/movie-style presentation where supported."""
    try:
        xbmcplugin.setPluginCategory(HANDLE, category)
        xbmcplugin.setContent(HANDLE, "movies")
    except Exception as e:
        xbmc.log("ExampleGanesh UI setup warning: %s" % str(e), xbmc.LOGWARNING)


def clear_cache():
    global _HTML_CACHE, _IMAGE_CACHE
    try:
        if not xbmcgui.Dialog().yesno("Clear Cache", "Clear cached website pages and poster images?\nYour settings and playback history will be kept."):
            return
    except Exception:
        pass
    _HTML_CACHE = {}
    _IMAGE_CACHE = {}
    try:
        # Keep playback history and recent searches; clear only fetched HTML/artwork.
        store = _load_cache_store()
        store["html"] = {}
        store["art"] = {}
        _save_cache_store(store)
        xbmcgui.Dialog().notification("Cache", "Page and artwork cache cleared", xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as e:
        xbmc.log("ExampleGanesh cache clear error: %s" % str(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Cache", "Failed to clear cache", xbmcgui.NOTIFICATION_ERROR, 2500)
    # Stay on the current home screen; refreshing the plugin root reopens the
    # modal and creates an endless setup/cache loop on some Kodi builds.


def add_search_entry(section_index=None):
    params = {"action": "search"}
    if section_index is not None:
        params["section_index"] = str(section_index)
    li = xbmcgui.ListItem(label="Search Titles")
    li.setArt({"icon": "DefaultSearch.png", "thumb": "DefaultSearch.png"})
    li.setInfo("video", {"title": "Search Titles"})
    xbmcplugin.addDirectoryItem(HANDLE, make_url(params), li, isFolder=True)


def add_pagination(title, action, url, section_index, page, art=""):
    display_title = ("◀  Previous" if title == "Previous" else "Next  ▶" if title == "Next" else title)
    li = xbmcgui.ListItem(label=display_title)
    set_art(li, art)
    params = {
        "action": action,
        "url": url,
        "section_index": str(section_index),
        "page": str(page),
    }
    xbmcplugin.addDirectoryItem(HANDLE, make_url(params), li, isFolder=True)


def get_recent_searches():
    return _load_cache_store().get("recent_searches", [])[:MAX_RECENT_SEARCHES]

def remember_search(term):
    term = clean_title(term)
    if not term:
        return
    store = _load_cache_store()
    searches = [x for x in store.get("recent_searches", []) if x.casefold() != term.casefold()]
    searches.insert(0, term)
    store["recent_searches"] = searches[:MAX_RECENT_SEARCHES]
    _save_cache_store(store)

def prompt_search():
    try:
        recent = get_recent_searches()
        if recent:
            entries = [{"label": "NEW SEARCH", "kind": "search_new"}]
            entries.extend({
                "label": term,
                "kind": "search_recent",
                "term": term
            } for term in recent)
            window = ExampleGaneshReleaseWindow(
                "exampleganesh-release.xml",
                xbmcaddon.Addon(ADDON_ID).getAddonInfo("path"),
                "Default", "1080i"
            )
            window.set_start(
                "SEARCH TITLES", "", entries, "",
                subtitle="Choose a recent search or start a new one",
                mode="search"
            )
            window.doModal()
            choice = window._choice
            del window
            if not choice:
                return ""
            if choice[0] == "recent":
                return choice[1]
        return xbmcgui.Dialog().input("Search Titles", type=xbmcgui.INPUT_ALPHANUM).strip()
    except Exception:
        return ""


def list_sections(url):
    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Addon Error", "Failed to open website", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh website open error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    page_art = get_page_image(soup, final_url)

    magnets = extract_magnets_from_page(soup, final_url)
    if magnets:
        configure_browse_ui("Latest")
        for m in magnets:
            add_magnet(m["title"], m["magnet"], m["art"])
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    sections = extract_sections(soup)
    configure_browse_ui("Browse")
    if not sections:
        xbmcgui.Dialog().notification("No Content", "No sections or magnets found", xbmcgui.NOTIFICATION_WARNING, 4000)

    for index, section in enumerate(sections):
        add_folder(section["title"], "section", final_url, section_index=index, art=page_art)
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def fetch_visible_artwork(items, final_url, fallback_art=""):
    """Fetch visible L4 artwork concurrently without changing item order."""
    results = [fallback_art] * len(items)

    def fetch_one(index, item):
        for link in item.get("links", []):
            href = link.get("url", "")
            full_url = urllib.parse.urljoin(final_url, href)
            if full_url.startswith("http") and is_allowed_url(full_url):
                art = get_image_from_link(full_url)
                if art:
                    return index, art
        return index, fallback_art

    # A small pool keeps Kodi responsive while avoiding a large request burst.
    with ThreadPoolExecutor(max_workers=min(5, max(1, len(items)))) as executor:
        futures = [executor.submit(fetch_one, i, item) for i, item in enumerate(items)]
        for future in as_completed(futures):
            try:
                index, art = future.result()
                results[index] = art
            except Exception as e:
                xbmc.log("ExampleGanesh artwork worker error: %s" % str(e), xbmc.LOGWARNING)

    return results


def render_section_items(url, final_url, section, section_index, page=0, search_term="", fallback_art=""):
    """Render only one L1 page, so L4 artwork is fetched only for visible titles."""
    items = section["items"]
    if search_term:
        needle = search_term.casefold()
        items = [item for item in items if needle in item["title"].casefold()]

    total = len(items)
    start = max(0, int(page) * ITEMS_PER_PAGE)
    visible = items[start:start + ITEMS_PER_PAGE]

    artwork = fetch_visible_artwork(visible, final_url, fallback_art)

    for relative_index, item in enumerate(visible):
        original_index = next(
            (i for i, candidate in enumerate(section["items"]) if candidate is item),
            start + relative_index,
        )
        item_art = artwork[relative_index]

        add_folder(
            item["title"],
            "item",
            final_url,
            section_index=section_index,
            item_index=original_index,
            art=item_art,
            label2=item.get("subtitle", ""),
        )

    if not search_term and start > 0:
        add_pagination("Previous", "section", final_url, section_index, page - 1)
    if not search_term and start + ITEMS_PER_PAGE < total:
        add_pagination("Next", "section", final_url, section_index, page + 1)


def list_section_items(url, section_index, page=0):
    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Addon Error", "Failed to open section", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh section open error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    sections = extract_sections(soup)

    try:
        section = sections[int(section_index)]
    except Exception:
        xbmcgui.Dialog().notification("Addon Error", "Section not found", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    configure_browse_ui(section["title"])
    add_search_entry(section_index)
    render_section_items(url, final_url, section, int(section_index), int(page), fallback_art=get_page_image(soup, final_url))
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def search_titles(url, section_index=None, term=None, page=0):
    if term is None:
        term = prompt_search()
    if not term:
        # Complete this plugin directory invocation without refreshing its parent.
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)
        except TypeError:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        return
    remember_search(term)

    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Search Error", "Failed to search website", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh search error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    sections = extract_sections(soup)
    needle = term.casefold()

    # With a section index, search every title in that section, not just the
    # currently visible 15. Without it, search all L1 sections on the page.
    if section_index is not None:
        selected = [(int(section_index), sections[int(section_index)])] if 0 <= int(section_index) < len(sections) else []
    else:
        selected = list(enumerate(sections))

    configure_browse_ui("Search: " + term)
    matches = []
    for sec_index, section in selected:
        for item_index, item in enumerate(section["items"]):
            if needle in item["title"].casefold():
                matches.append((sec_index, section["title"], item_index, item))

    found = len(matches)
    page = max(0, int(page))
    visible_matches = matches[page * ITEMS_PER_PAGE:(page + 1) * ITEMS_PER_PAGE]
    artwork = fetch_visible_artwork([m[3] for m in visible_matches], final_url)
    for match_index, (sec_index, section_title, item_index, item) in enumerate(visible_matches):
        add_folder(
            item["title"],
            "item",
            final_url,
            section_index=sec_index,
            item_index=item_index,
            art=artwork[match_index],
            label2=item.get("subtitle", "") or section_title,
        )

    if page > 0:
        li = xbmcgui.ListItem(label="Previous Search Results")
        li.setInfo("video", {"title": "Previous Search Results"})
        xbmcplugin.addDirectoryItem(HANDLE, make_url({"action": "search_page", "url": url, "section_index": section_index if section_index is not None else "", "term": term, "page": page - 1}), li, isFolder=True)
    if (page + 1) * ITEMS_PER_PAGE < found:
        li = xbmcgui.ListItem(label="Next Search Results")
        li.setInfo("video", {"title": "Next Search Results"})
        xbmcplugin.addDirectoryItem(HANDLE, make_url({"action": "search_page", "url": url, "section_index": section_index if section_index is not None else "", "term": term, "page": page + 1}), li, isFolder=True)
    if not found:
        xbmcgui.Dialog().notification("Search", "No matching titles found", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def list_item_links(url, section_index, item_index):
    try:
        html, final_url = get_html(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Addon Error", "Failed to open item", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmc.log("ExampleGanesh item open error: " + str(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    soup = BeautifulSoup(html, "html.parser")
    page_art = get_page_image(soup, final_url)

    magnets = extract_magnets_from_page(soup, final_url)
    if magnets:
        movie_title = ""
        try:
            movie_title = extract_sections(soup)[int(section_index)]["items"][int(item_index)]["title"]
        except Exception:
            movie_title = clean_title(soup.title.get_text(" ", strip=True) if soup.title else "")
        choose_magnet_and_play(magnets, movie_title)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    sections = extract_sections(soup)
    try:
        item = sections[int(section_index)]["items"][int(item_index)]
    except Exception:
        xbmcgui.Dialog().notification("Addon Error", "Item not found", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        apply_poster_view()
        return

    seen = set()
    for link in item["links"]:
        label = link["label"]
        href = link["url"]
        full_url = urllib.parse.urljoin(final_url, href)
        if full_url in seen:
            continue
        seen.add(full_url)
        if full_url.startswith("magnet:"):
            add_magnet(label, full_url, page_art)
        elif full_url.startswith("http") and is_allowed_url(full_url):
            # Skip the extra intermediate directory item when the linked page
            # contains result entries that the addon already knows how to show.
            try:
                result_html, result_final_url = get_html(full_url)
                result_soup = BeautifulSoup(result_html, "html.parser")
                result_magnets = extract_magnets_from_page(result_soup, result_final_url)
            except Exception as e:
                xbmc.log("ExampleGanesh direct result fetch error: %s" % str(e), xbmc.LOGWARNING)
                result_magnets = []
            if result_magnets:
                configure_browse_ui("Choose Release")
                choose_magnet_and_play(result_magnets, item.get("title", ""))
                xbmcplugin.endOfDirectory(HANDLE)
                apply_poster_view()
                return
            add_page_link(label, full_url, page_art)
    xbmcplugin.endOfDirectory(HANDLE)
    apply_poster_view()


def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action")
    url = params.get("url", get_base_url())

    if action == "setup":
        website_setup()
    elif action == "play_magnet":
        play_magnet(params.get("magnet", ""), params.get("title", ""), params.get("art", ""))
    elif action == "recent":
        list_recently_played()
    elif action == "search_page":
        section_value = params.get("section_index", "")
        search_titles(url, int(section_value) if section_value != "" else None,
                      params.get("term", ""), params.get("page", "0"))
    elif action == "clear_cache":
        clear_cache()
    elif action == "open":
        list_sections(url)
    elif action == "section":
        list_section_items(url, params.get("section_index", "0"), params.get("page", "0"))
    elif action == "search":
        list_sections_url = url
        list_section_index = params.get("section_index")
        search_titles(list_sections_url, list_section_index, params.get("term"))
    elif action == "item":
        list_item_links(url, params.get("section_index", "0"), params.get("item_index", "0"))
    else:
        list_home()


router()
