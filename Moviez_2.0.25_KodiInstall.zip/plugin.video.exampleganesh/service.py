import xbmc
import xbmcaddon


ADDON_ID = "plugin.video.exampleganesh"
STARTUP_DELAY_SECONDS = 10


def main():
    addon = xbmcaddon.Addon(ADDON_ID)
    monitor = xbmc.Monitor()
    should_open = addon.getSetting("open_on_startup").strip().lower() == "true"
    if should_open and not monitor.waitForAbort(STARTUP_DELAY_SECONDS):
        should_open = (
            not monitor.abortRequested()
            and addon.getSetting("open_on_startup").strip().lower() == "true"
        )
    else:
        should_open = False

    if should_open:
        xbmc.executebuiltin(
            "ActivateWindow(Videos,plugin://plugin.video.exampleganesh/,return)"
        )
    while not monitor.waitForAbort(60):
        pass


if __name__ == "__main__":
    main()
